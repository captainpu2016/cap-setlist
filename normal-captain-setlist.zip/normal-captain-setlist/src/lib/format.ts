/** 秒數轉 mm:ss，null 時回傳 undefined 讓呼叫端決定要不要顯示 */
export function formatDuration(seconds: number | null | undefined): string | undefined {
  if (seconds == null || Number.isNaN(seconds)) return undefined;
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

/** 整份歌單總長度（秒），忽略沒有時長資料的曲目 */
export function sumDuration(seconds: (number | null)[]): number {
  return seconds.reduce((total: number, s) => total + (s ?? 0), 0);
}

export function formatShowDate(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('zh-TW', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'short' });
}

/** 從 Spotify 網址（open.spotify.com/track/{id}）解析出純 track ID */
export function parseSpotifyTrackId(url: string): string | null {
  const trimmed = url.trim();
  if (!trimmed) return null;
  // 允許使用者直接貼純 ID
  if (/^[a-zA-Z0-9]{15,25}$/.test(trimmed) && !trimmed.includes('/')) return trimmed;
  const match = trimmed.match(/track\/([a-zA-Z0-9]+)/);
  return match ? match[1] : null;
}

/** slug 化：中文保留、空白轉 -、移除特殊符號，供場次網址使用 */
export function slugify(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s-]/gu, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}
